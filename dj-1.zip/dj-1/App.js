import React, { Component } from 'react';
import { Button, View, Text } from 'react-native';

class GreenButton extends Component {
  displayAlert = () => {
    alert('I am an alert box');
  };
  render() {
    return (
      <View 
      style={{ width: 200, height: 100, marginTop: 1, marginLeft: 50 }}>
        <Button
          title="sound 5"
          color="green"
          onPress={this.displayAlert}
        />
      </View>
    );
  }
}
class PurpleColorButton extends Component {
  displayAlert = () => {
    alert('I am an alert box');
  };
  render() {
    return (
      <View 
        style={{ width: 200, height: 100, marginTop: 10, marginLeft: 50 }}>
        <Button
          title="sound2"
          color="purple"
          onPress={this.displayAlert}
        />
      </View>
    );
  }
}
class RedButton extends Component {
  displayAlert = () => {
    alert('I am an alert box');
  };
  render() {
    return (
      <View 
      style={{ width: 200, height: 100, marginTop: 10, marginLeft: 50 }}>
        <Button
          title="sound3"
          color="red"
          onPress={this.displayAlert}
        />
      </View>
    );
  }
}

class YellowButton extends Component {
  displayAlert = () => {
    alert('I am an alert box');
  };
  render() {
    return (
      <View 
        style={{ width: 200, height: 100, marginTop: 10, marginLeft: 50 }}>
        <Button
          title="sound4"          
          color="yellow"
          onPress={this.displayAlert}
        />
      </View>
    );
  }
}
class BlueButton extends Component {
  displayAlert = () => {
    alert('I am an alert box');
  };
  render() {
    return (
      <View style={{ width: 200, height: 100, marginTop: 10, marginLeft: 50 }}>
        <Button
          title="sound1"
          color="blue"
          onPress={this.displayAlert}
        />
      </View>
    );
  }
}

export default class App extends Component {
  render() {
    return (
      <View style={{ marginTop: 20 }}>
        <BlueButton/>
        <PurpleColorButton/>
        <RedButton/>
        <YellowButton/>
        <GreenButton/>
      </View>
    );
  }
}
